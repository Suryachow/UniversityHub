This is a Simple Task Management System using the MVC architecture in a Java application. The system allows user to:
Add new tasks with a title, description   and due date.
View a list of all tasks.
Mark tasks as completed.
Delete tasks.

